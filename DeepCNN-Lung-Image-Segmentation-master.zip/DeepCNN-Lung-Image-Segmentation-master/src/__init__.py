from .DeepCNN_model import DeepCNN
from .mobile_net_model import MobileNet
from .vgg_model import VGGModel