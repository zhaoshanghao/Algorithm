* About files.
This program is behavior analysis program to use K-NN. The main.c is main program. The func.h is library for K-NN. That file has function for load train data, load test data and knn.

The Teacher is sample data for k-nn train.
The Test is sample data for k-nn test.

