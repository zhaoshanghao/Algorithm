/*
 * Title: func.c
 * Feature: This header is for knn program.
 * 
 * Univ: University of Aizu
 * Author: Yuki Numanami <s1240214@u-aizu.ac.jp>
 *
 * Change log:
 *  - 2018/08/30: Initial version
 *
 * Since:
 *  - 2018/08/30
 */

// NUMD is the number of sensor data.
// Sensor data list:
// ax,ay,az,gx,gy,gz,mx,my,mz,temperature,q0,q1,q2,q3,altitude,pressure,battery
// a is acceleration. g is angular velocity. m is magnetism. q is quaternions.
#define NUMD 17

// NUMA is the number of answer. For example, if the train data has label of 0 to 3, the NUMA is 4.
// This program suppose the label number begins at 0.
#define NUMA 6

// NUMU is the number of using data for knn
// For example, if use mean of acceleration and variance of acceleration for knn, this number is 6.
#define NUMU 6

// NUM_KNN is the number of K for k-nn
#define NUM_KNN 5

// These values are range of sensor data.
#define RANGE_A 2      // accelaration
#define RANGE_G 200    // angular velocity
#define RANGE_M 200    // magnetism
#define RANGE_Q 200    // quaternions

typedef struct _sdata {
    double sensordata[NUMD];
    int label;
    struct _sdata *next;
} sdata;

typedef struct _data {
    double data[NUMU];
    int label;
    struct _data *next;
} data;

typedef struct _dist {
    double dist;
    int label;
} dist;

extern data train;        // Train data
extern int numTrain;      // The number of Train data.
extern data test;         // Test data
extern int numTest;       // The number of test data.
extern dist *distList;    // Distance data

// Load train data from filename file.
void loadTrain(char *filename, int windowSize, int movingDist);

// Get a distance between dataA to dataB. n is the number of dataA.
double getDist(double dataA[], double dataB[], int n);

// Load test data from filename file.
void loadTest(char *filename, int windowSize, int movingDist);

// This function is for sort.
int discmp(const void *, const void *);

// For knn program. It is used after distance data is prepared.
int knn();

// It calculate data x, y, z normalization.
void normalization(double *x, double *y, double *z);

// Create data.
void createData(sdata *sp, int windowSize, int label, data *);
