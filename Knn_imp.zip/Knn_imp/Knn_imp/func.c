/*
 * Title: func.c
 * Feature: This header is for knn program.
 * 
 * Univ: University of Aizu
 * Author: Yuki Numanami <s1240214@u-aizu.ac.jp>
 *
 * Change log:
 *  - 2018/08/30: Initial version
 *
 * Since:
 *  - 2018/08/30
 */

#include "func.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

data train;
data test;
int numTrain = 0;
int numTest = 0;

/***************************************************************
FUNCTION: get a feature data in a window.
INPUT   : data : head pointer of window of sensor data.
          windowSize : slide window size.
          label : the label of behavior.
          new : a feature data. This funciton is to crate this.
OUTPUT  : new : a feature data.
***************************************************************/
void createData(sdata *sp, int windowSize, int label, data *new) {    // {{{
    sdata *wp = sp;

    // init new value // {{{
    for (int i = 0; i < NUMU; i++) {
        new->data[i] = 0;
    }
    new->label = label;
    new->next = NULL;    // }}}

    const double norm_a = sqrt(3 * (RANGE_A * RANGE_A));
    for (int i = 0; i < windowSize; i++) {
        // create window
        new->data[0] += wp->sensordata[0] / norm_a;
        new->data[1] += wp->sensordata[1] / norm_a;
        new->data[2] += wp->sensordata[2] / norm_a;
        new->data[3] += (wp->sensordata[0] / norm_a) * (wp->sensordata[0] / norm_a);
        new->data[4] += (wp->sensordata[1] / norm_a) * (wp->sensordata[1] / norm_a);
        new->data[5] += (wp->sensordata[2] / norm_a) * (wp->sensordata[2] / norm_a);

        // step
        wp = wp->next;
        if (wp->next == NULL) return;
    }

    new->data[0] = new->data[0] / windowSize;
    new->data[1] = new->data[1] / windowSize;
    new->data[2] = new->data[2] / windowSize;
    new->data[3] = new->data[3] / windowSize - new->data[0];
    new->data[4] = new->data[4] / windowSize - new->data[1];
    new->data[5] = new->data[5] / windowSize - new->data[2];
}    // }}}

/***************************************************************
FUNCTION: get the training samples
INPUT   : filename : txt file storage the training raw data
          windowSize : slide window size
          movingDist : step size
OUTPUT  : train : the training sample
***************************************************************/
void loadTrain(char *filename, int windowSize, int movingDist) {    // {{{
    FILE *read;
    sdata head;
    sdata *point;
    data *tpoint;

    // init
    head.next = NULL;
    train.next = NULL;
    tpoint = &train;

    for (int label = 0; label < NUMA; label++) {
        // open teacher data
        read = fopen(filename, "r");
        if (read == NULL) {
            fprintf(stderr, "%s is not existed.", filename);
            exit(2);
        }

        // Read all data from teacher data {{{
        point = &head;
        int count = 0;
        while (fscanf(read, "%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%d", &point->sensordata[0], &point->sensordata[1], &point->sensordata[2], &point->sensordata[3], &point->sensordata[4], &point->sensordata[5], &point->sensordata[6], &point->sensordata[7], &point->sensordata[8], &point->sensordata[9], &point->sensordata[10], &point->sensordata[11], &point->sensordata[12], &point->sensordata[13], &point->sensordata[14], &point->sensordata[15], &point->sensordata[16], &point->label) != EOF) {
            /* point->label = count;    // TODO: test */

            if (point->label == label) {
                point->label = count;
                sdata *new;
                new = (sdata *)malloc(sizeof(sdata));
                new->next = NULL;
                point->next = new;
                point = point->next;
                count++;
            }
        }    // }}}

        // create train data
        point = &head;
        /* printf("count: %d, start: 0, windowSize: %d, movingDist: %d\n", count, windowSize, movingDist); */
        for (int i = 0; i < count - windowSize; i += movingDist) {
            // window
            // calculate mean and variance.

            // create a data.
            createData(point, windowSize, label, tpoint);

            // init for next data
            data *new;
            new = (data *)malloc(sizeof(data));
            new->next = NULL;
            tpoint->next = new;
            tpoint = tpoint->next;
            numTrain += 1;
            // moving
            for (int j = 0; j < movingDist; j++) {
                point = point->next;
                if (point->next == NULL) break;
            }
        }

        fclose(read);
    }

}    // }}}

/***************************************************************
FUNCTION: get the Eulidean distance between two multidimension feature vectors
INPUT   : dataA : feature vector
          dataB : feature vector
          n: the length of the selected feature vector
OUTPUT  : squre root distance between the two vectors
METHOD  : sqrt
***************************************************************/
double getDist(double dataA[], double dataB[], int n) {    // {{{
    double res = 0;
    for (int i = 0; i < n; i++) {
        double temp = dataA[i] - dataB[i];
        res += temp * temp;
    }
    res = sqrt(res);

    return res;
}    // }}}

void loadTest(char *filename, int windowSize, int movingDist) {    // {{{
    data *point = &test;
    point->next = NULL;
    printf("Start to load test data\n");

    for (int label = 0; label < NUMA; label++) {
        // init
        FILE *read;
        sdata head;
        sdata *hp = &head;
        hp->next = NULL;

        if ((read = fopen(filename, "r")) == NULL) {
            fprintf(stderr, "%s is not existed.", filename);
            exit(2);
        }

        // Read all data for test from file. {{{
        int count = 0;
        while (fscanf(read, "%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%d", &hp->sensordata[0], &hp->sensordata[1], &hp->sensordata[2], &hp->sensordata[3], &hp->sensordata[4], &hp->sensordata[5], &hp->sensordata[6], &hp->sensordata[7], &hp->sensordata[8], &hp->sensordata[9], &hp->sensordata[10], &hp->sensordata[11], &hp->sensordata[12], &hp->sensordata[13], &hp->sensordata[14], &hp->sensordata[15], &hp->sensordata[16], &hp->label) != EOF) {
            // get next sensor data

            if (hp->label == label) {
                count += 1;
                // printf("%d: %lf %d\n", count, hp->sensordata[0], hp->label);

                sdata *new = (sdata *)malloc(sizeof(sdata));
                new->next = NULL;
                hp->next = new;
                hp = hp->next;
            }
        }    // }}}

        // Calculate test data.
        hp = &head;
        for (int i = 0; i < count - movingDist; i += movingDist) {
            // create a test data.
            for (int j = 0; j < NUMU; j++) {
                point->data[j] = 0;
            }

            createData(hp, windowSize, label, point);
            numTest++;

            // init next data.
            data *new = (data *)malloc(sizeof(data));
            new->next = NULL;
            point->next = new;
            point = point->next;

            // move
            for (int j = 0; j < movingDist; j++) {
                hp = hp->next;
            }
        }
        fclose(read);
    }

}    // }}}

/***************************************************************
FUNCTION: compare two distance
INPUT   : distance a, and b
OUTPUT  : -1 --> a<b
          0  --> a=b
          1  --> a>b
METHOD  :
***************************************************************/
int discmp(const void *a, const void *b) {    // {{{
    return (int)((((dist *)a)->dist - ((dist *)b)->dist) * 10);
}    // }}}

/***************************************************************
FUNCTION: output the estimated class based on naive KNN algorithm
INPUT   : NULL
OUTPUT  : the label of the majority class
METHOD  : majority voting based on the Euclidean distance
***************************************************************/
int knn() {    // {{{
    int i;
    int res[NUMA];

    // init
    for (i = 0; i < NUMA; i++) {
        res[i] = 0;
    }

    qsort(distList, numTrain, sizeof(dist), discmp);
    int maxi = -1;
    int max = -1;
    for (i = 0; i < NUM_KNN; i++) {
        /* printf("%lf, ", data[i].dist); */
        res[distList[i].label] += 1;
        if (max < res[distList[i].label]) {
            max = res[distList[i].label];
            maxi = distList[i].label;
        }
    }
    /* for (i = 0; i < NUMA; i++) { */
    /*     printf("%d ", res[i]); */
    /* } */

    return maxi;
}    // }}}

/***************************************************************
FUNCTION: nomalize the raw data in the same range [-1, 1]
INPUT   : double *x   //raw x
          double *y   //raw y
          double *z   //raw z
OUTPUT  : normalized x, y, z
METHOD  : raw_data/range_of_the_data
***************************************************************/
void normalization(double *x, double *y, double *z) {    // {{{
    double res;
    res = *x * *x + *y * *y + *z * *z;
    res = sqrt(res);

    *x /= res;
    *y /= res;
    *z /= res;
}    // }}}
