#include "func.h"
#include <stdio.h>
#include <stdlib.h>

dist *distList;

int main() {
    data *tpoint;
    int confusion[NUMA][NUMA];

    // load train data.
    // argument: filename, windowSize, movingDist
    printf("load train\n");
    loadTrain("train.txt", 10, 5);
    printf("Number of train data: %d\n", numTrain);

    // load test data
    // argument: filename, windowSize, movingDist
    printf("load test\n");
    loadTest("test.txt", 10, 5);
    printf("Number of test data: %d\n", numTest);

    // k-nn
    // init
    printf("Start K-NN\n");
    distList = (dist *)malloc(sizeof(dist) * numTrain);    // init dist data
    for (int i = 0; i < NUMA; i++) {                       // init confusion matrix
        for (int j = 0; j < NUMA; j++) {
            confusion[i][j] = 0;
        }
    }

    for (data *testp = &test; testp->next != NULL; testp = testp->next) {
        // calculate test data to train data.
        int count = 0;
        for (tpoint = &train; tpoint->next != NULL; tpoint = tpoint->next) {
            distList[count].dist = getDist(testp->data, tpoint->data, NUMU);
            distList[count].label = tpoint->label;

            count += 1;
        }
        int knnRes = knn();
        confusion[knnRes][testp->label] += 1;
    }

    // show confusion matrix
    printf("actual \\ predict\n");
    printf("\t  \\ ");
    for (int i = 0; i < NUMA; i++) {
        printf("%3d ", i);
    }
    printf("\n");
    for (int i = 0; i < NUMA; i++) {
        printf("\t%3d ", i);
        for (int j = 0; j < NUMA; j++) {
            printf("%3d ", confusion[j][i]);
        }
        printf("\n");
    }
    float rate;
    float rightanswers=0, allanswers=0;
    for (int i = 0; i < NUMA; i++) {
        rightanswers += confusion[i][i];
        for (int j = 0; j < NUMA; j++) {
            allanswers += confusion[j][i];
        }
        printf("\n");
    }
    rate = rightanswers/allanswers;
    printf("%f ", rate);
    printf("\n");

    return 0;
}
